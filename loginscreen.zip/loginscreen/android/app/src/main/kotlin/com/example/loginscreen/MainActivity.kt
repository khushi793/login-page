package com.example.loginscreen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

}
